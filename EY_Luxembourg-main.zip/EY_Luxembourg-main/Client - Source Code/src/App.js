import { useEffect, useState } from 'react';
import WeightedGraph from './algo.js'
import logo from './logo.svg';
import './App.css';
import List from './List.js';

import MyGuichet from './MyGuichet.js';

function App() {
        
  return (
    <div>
        <MyGuichet/>            
    </div>
  );
}

export default App;